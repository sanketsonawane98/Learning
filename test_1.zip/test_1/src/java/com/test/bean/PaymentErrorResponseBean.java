/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.test.bean;

/**
 *
 * @author Sanket.Sonawane
 */
public class PaymentErrorResponseBean {
    
    private String errorMessage;
    private String statusCode;

    public String getStatusCode() {
        return statusCode;
    }

    public void setStatusCode(String statusCode) {
        this.statusCode = statusCode;
    }

    public String getErrorMessage() {
        return errorMessage;
    }

    public void setErrorMessage(String errorMessage) {
        this.errorMessage = errorMessage;
    }

    @Override
    public String toString() {
        return "PaymentErrorResponseBean{" + "errorMessage=" + errorMessage + ", statusCode=" + statusCode + '}';
    }
    
}
