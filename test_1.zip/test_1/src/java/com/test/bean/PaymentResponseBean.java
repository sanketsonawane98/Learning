/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.test.bean;

/**
 *
 * @author Sanket.Sonawane
 */
public class PaymentResponseBean {

    private String statusCode;
    private String successMessage;
    private int clientId;
    private String version;
    private String txnAmount;
    private String txnStatus;
    private String txnDescription;
    private String txnDateTime;
    private String txnRefNo;
    private String policyRefNumber;
    private String referenceField1;
    private String referenceField2;
    private String referenceField3;
    private String tenure;
    private String emiAmount;
    private String interestCharged;
    private String interestPercent;
    private String processingFee;
    private String downpaymentAmount;

    public String getStatusCode() {
        return statusCode;
    }

    public void setStatusCode(String statusCode) {
        this.statusCode = statusCode;
    }

    public String getSuccessMessage() {
        return successMessage;
    }

    public void setSuccessMessage(String successMessage) {
        this.successMessage = successMessage;
    }

    public int getClientId() {
        return clientId;
    }

    public void setClientId(int clientId) {
        this.clientId = clientId;
    }

    public String getVersion() {
        return version;
    }

    public void setVersion(String version) {
        this.version = version;
    }

    public String getTxnAmount() {
        return txnAmount;
    }

    public void setTxnAmount(String txnAmount) {
        this.txnAmount = txnAmount;
    }

    public String getTxnStatus() {
        return txnStatus;
    }

    public void setTxnStatus(String txnStatus) {
        this.txnStatus = txnStatus;
    }

    public String getTxnDescription() {
        return txnDescription;
    }

    public void setTxnDescription(String txnDescription) {
        this.txnDescription = txnDescription;
    }

    public String getTxnDateTime() {
        return txnDateTime;
    }

    public void setTxnDateTime(String txnDateTime) {
        this.txnDateTime = txnDateTime;
    }

    public String getTxnRefNo() {
        return txnRefNo;
    }

    public void setTxnRefNo(String txnRefNo) {
        this.txnRefNo = txnRefNo;
    }

    public String getPolicyRefNumber() {
        return policyRefNumber;
    }

    public void setPolicyRefNumber(String policyRefNumber) {
        this.policyRefNumber = policyRefNumber;
    }

    public String getReferenceField1() {
        return referenceField1;
    }

    public void setReferenceField1(String referenceField1) {
        this.referenceField1 = referenceField1;
    }

    public String getReferenceField2() {
        return referenceField2;
    }

    public void setReferenceField2(String referenceField2) {
        this.referenceField2 = referenceField2;
    }

    public String getReferenceField3() {
        return referenceField3;
    }

    public void setReferenceField3(String referenceField3) {
        this.referenceField3 = referenceField3;
    }

    public String getTenure() {
        return tenure;
    }

    public void setTenure(String tenure) {
        this.tenure = tenure;
    }

    public String getEmiAmount() {
        return emiAmount;
    }

    public void setEmiAmount(String emiAmount) {
        this.emiAmount = emiAmount;
    }

    public String getInterestCharged() {
        return interestCharged;
    }

    public void setInterestCharged(String interestCharged) {
        this.interestCharged = interestCharged;
    }

    public String getInterestPercent() {
        return interestPercent;
    }

    public void setInterestPercent(String interestPercent) {
        this.interestPercent = interestPercent;
    }

    public String getProcessingFee() {
        return processingFee;
    }

    public void setProcessingFee(String processingFee) {
        this.processingFee = processingFee;
    }

    public String getDownpaymentAmount() {
        return downpaymentAmount;
    }

    public void setDownpaymentAmount(String downpaymentAmount) {
        this.downpaymentAmount = downpaymentAmount;
    }

    @Override
    public String toString() {
        return "PaymentResponseBean{" + "statusCode=" + statusCode + ", successMessage=" + successMessage + ", clientId=" + clientId + ", version=" + version + ", txnAmount=" + txnAmount + ", txnStatus=" + txnStatus + ", txnDescription=" + txnDescription + ", txnDateTime=" + txnDateTime + ", txnRefNo=" + txnRefNo + ", policyRefNumber=" + policyRefNumber + ", referenceField1=" + referenceField1 + ", referenceField2=" + referenceField2 + ", referenceField3=" + referenceField3 + ", tenure=" + tenure + ", emiAmount=" + emiAmount + ", interestCharged=" + interestCharged + ", interestPercent=" + interestPercent + ", processingFee=" + processingFee + ", downpaymentAmount=" + downpaymentAmount + '}';
    }

}