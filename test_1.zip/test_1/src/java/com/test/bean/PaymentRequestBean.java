/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.test.bean;

/**
 *
 * @author Sanket.Sonawane
 */
public class PaymentRequestBean {
    
    String serviceName;
    String serviceMethod;
    String policyRefNumber;
    String partnerId;
    String clientId;
    String clientKey;
    String version;
    String roles;
    String loggedInUniqueIdentifierId;
    String loggedInUserId;

    public String getServiceName() {
        return serviceName;
    }

    public void setServiceName(String serviceName) {
        this.serviceName = serviceName;
    }

    public String getServiceMethod() {
        return serviceMethod;
    }

    public void setServiceMethod(String serviceMethod) {
        this.serviceMethod = serviceMethod;
    }

    public String getPolicyRefNumber() {
        return policyRefNumber;
    }

    public void setPolicyRefNumber(String policyRefNumber) {
        this.policyRefNumber = policyRefNumber;
    }

    public String getPartnerId() {
        return partnerId;
    }

    public void setPartnerId(String partnerId) {
        this.partnerId = partnerId;
    }

    public String getClientId() {
        return clientId;
    }

    public void setClientId(String clientId) {
        this.clientId = clientId;
    }

    public String getClientKey() {
        return clientKey;
    }

    public void setClientKey(String clientKey) {
        this.clientKey = clientKey;
    }

    public String getVersion() {
        return version;
    }

    public void setVersion(String version) {
        this.version = version;
    }

    public String getRoles() {
        return roles;
    }

    public void setRoles(String roles) {
        this.roles = roles;
    }

    public String getLoggedInUniqueIdentifierId() {
        return loggedInUniqueIdentifierId;
    }

    public void setLoggedInUniqueIdentifierId(String loggedInUniqueIdentifierId) {
        this.loggedInUniqueIdentifierId = loggedInUniqueIdentifierId;
    }

    public String getLoggedInUserId() {
        return loggedInUserId;
    }

    public void setLoggedInUserId(String loggedInUserId) {
        this.loggedInUserId = loggedInUserId;
    }

    @Override
    public String toString() {
        return "PaymentRequestBean{" + "serviceName=" + serviceName + ", serviceMethod=" + serviceMethod + ", policyRefNumber=" + policyRefNumber + ", partnerId=" + partnerId + ", clientId=" + clientId + ", clientKey=" + clientKey + ", version=" + version + ", roles=" + roles + ", loggedInUniqueIdentifierId=" + loggedInUniqueIdentifierId + ", loggedInUserId=" + loggedInUserId + '}';
    }
    
    
    
}
