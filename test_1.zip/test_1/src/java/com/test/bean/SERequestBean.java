/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.test.bean;

/**
 *
 * @author Sanket.Sonawane
 */
public class SERequestBean {
    
    private String id_number;
    private String state_code;
    private String verify_type;

    public String getId_number() {
        return id_number;
    }

    public void setId_number(String id_number) {
        this.id_number = id_number;
    }

    public String getState_code() {
        return state_code;
    }

    public void setState_code(String state_code) {
        this.state_code = state_code;
    }

    public String getVerify_type() {
        return verify_type;
    }

    public void setVerify_type(String verify_type) {
        this.verify_type = verify_type;
    }

    @Override
    public String toString() {
        return "SERequestBean{" + "id_number=" + id_number + ", state_code=" + state_code + ", verify_type=" + verify_type + '}';
    }
    
    
    
    
}
