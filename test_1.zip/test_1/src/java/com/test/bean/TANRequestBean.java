/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.test.bean;

/**
 *
 * @author Sanket.Sonawane
 */
public class TANRequestBean {
    
    private String verify_type;
    private String id_number;


    public String getVerify_type() {
        return verify_type;
    }

    public void setVerify_type(String verify_type) {
        this.verify_type = verify_type;
    }

    public String getId_number() {
        return id_number;
    }

    public void setId_number(String id_number) {
        this.id_number = id_number;
    }

    @Override
    public String toString() {
        return "TANRequestBean{" + "verify_type=" + verify_type + ", id_number=" + id_number + '}';
    }

   

    
    
    
}
