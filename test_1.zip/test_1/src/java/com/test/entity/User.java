/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.test.entity;

/**
 *
 * @author Sanket.Sonawane
 */

import javax.persistence.Entity;
import javax.persistence.Id;
import lombok.Data;

@Entity
@Data
public class User {
    @Id
    private String username;
    private String password; // Store hashed password
    private String role; // e.g., "USER", "ADMIN"
}
