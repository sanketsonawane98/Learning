/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.test.controller;

import com.test.bean.CINRequestBean;
import com.test.bean.PaymentRequestBean;
import com.test.bean.SERequestBean;
import com.test.bean.TANRequestBean;
import com.test.entity.User;
import com.test.repository.UserRepository;
import com.test.service.PaymentService;
import com.test.service.commonService;
import java.net.InetSocketAddress;
import java.net.Proxy;
import java.util.HashMap;
import java.util.Map;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.client.SimpleClientHttpRequestFactory;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

/**
 *
 * @author Sanket.Sonawane
 */
@RestController
public class TANController {
    
    @Autowired
    private commonService ts;
    
    @Autowired
    private PaymentService ps;
    

    @RequestMapping(value = "/TAN", method = RequestMethod.POST)
    public ResponseEntity<String> test(@RequestBody TANRequestBean t)
    {
        
        ResponseEntity<String> tanRes = ts.getDetails(t);
        
        return tanRes;
    }
    
    @RequestMapping(value = "/CIN", method = RequestMethod.POST)
    public ResponseEntity<String> testCin(@RequestBody CINRequestBean c)
    {
        
        ResponseEntity<String> cinRes = ts.getDetails(c);
        
        return cinRes;
        
    }
    
    @RequestMapping(value = "/SE", method = RequestMethod.POST)
    public ResponseEntity<String> testSE(@RequestBody SERequestBean s)
    {
        
        ResponseEntity<String> seRes = ts.getDetails(s);
        
        return seRes;
        
    }
    
    @RequestMapping(value = "/Payment_status", method = RequestMethod.POST)
    public ResponseEntity<?> payment(@RequestBody PaymentRequestBean p)
    {
        
        ResponseEntity<?> PayRes = ps.getData(p);
        
        return PayRes;
    }
    
}
