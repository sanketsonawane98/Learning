/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.test.controller;
import java.net.InetSocketAddress;
import java.net.Proxy;
import java.util.HashMap;
import java.util.Map;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.http.client.SimpleClientHttpRequestFactory;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;

/**
 *
 * @author Sanket.Sonawane
 */
public class test {
    
    public static String makePostRequest(String url, Object formData) {
        try {
            
            
            SimpleClientHttpRequestFactory requestFactory = new SimpleClientHttpRequestFactory();
            Proxy proxy = new Proxy(Proxy.Type.HTTP, new InetSocketAddress("bgsrvpxy.bajajallianz.com", 8888));
            requestFactory.setProxy(proxy);
            RestTemplate restTemplate = new RestTemplate(requestFactory);
            

             HttpHeaders headers = new HttpHeaders();
             
             HttpEntity<?> requestEntity;
             
             headers.add("Content-Type", "application/json");
             headers.add("authentication-username","18027");
             headers.add("authentication-token","lmR3/DU4u9v79hX0fLrOx0OXSc4sL9tDf0uEAT9oN6g=");
            
            System.out.println("Sending request to: " + url);
            System.out.println("Form data: " + formData);
            
            requestEntity = new HttpEntity<>(formData, headers);
            
            //HttpEntity<MultiValueMap<String, String>> requestEntity = new HttpEntity<>(formData, headers);
            
            ResponseEntity<String> response = restTemplate.postForEntity(url, requestEntity, String.class);
            
            System.out.println("Status Code: " + response.getStatusCode());
            
       
            return response.getBody();
            
            
        } catch (Exception e) {
            System.err.println("Error making request: " + e.getMessage());
            e.printStackTrace();
            return "Error: " + e.getMessage();
        }
    }
    public static void main(String[] args)
    {
        
        System.out.println("--------------------- Query Api Generation -----------------------");
        System.out.println();
        
        String tokenUrl = "https://finsall.co.in/FinsAllServer/api";
        
                     
                Map<String, Object> jsonData = new HashMap<>();
                jsonData.put("serviceName", "PaymentService");
                jsonData.put("serviceMethod", "paymentStatus");
                jsonData.put("policyRefNumber", "FINSALLXXXPP2575");
                jsonData.put("partnerId", "FINSALL2063");
                jsonData.put("clientId", "2063");
                jsonData.put("clientKey", "126770bfd2ae4c1ab106be53897a61c9e27076a495595f8ac591d1fedbcd8b11");
                jsonData.put("version", "1.0.0");
                jsonData.put("roles", "executive");
                jsonData.put("loggedInUniqueIdentifierId", "47");
                jsonData.put("loggedInUserId", "18027");
        
        String tanRes = makePostRequest(
            tokenUrl,
            jsonData
        );
        
        System.out.println("TAN Response : "+tanRes);
        
        
    
                
    }
    
}
