/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.test.filter;

/**
 *
 * @author Sanket.Sonawane
 */

//import com.test.service.PaymentServiceImpl;
import io.github.bucket4j.Bandwidth;
import io.github.bucket4j.Bucket;
import io.github.bucket4j.Bucket4j;
import io.github.bucket4j.Refill;

import javax.servlet.*;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.time.Duration;
import java.util.concurrent.ConcurrentHashMap;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class Bucket4jRateLimitFilter implements Filter {
    
     private static final Logger logger = LoggerFactory.getLogger(Bucket4jRateLimitFilter.class);    

    
    private final ConcurrentHashMap<String, Bucket> clientBuckets = new ConcurrentHashMap<>();
    private int bucketCapacity = 10;
    private int refillTokens = 10;
    private int refillTimeInMinutes = 1;
    
    @Override
    public void init(FilterConfig filterConfig) throws ServletException {
        // Read configuration parameters if provided
        String capacity = filterConfig.getInitParameter("bucketCapacity");
        if (capacity != null) {
            bucketCapacity = Integer.parseInt(capacity);
        }
        
        String refillRate = filterConfig.getInitParameter("refillTokens");
        if (refillRate != null) {
            refillTokens = Integer.parseInt(refillRate);
        }
        
        String refillTime = filterConfig.getInitParameter("refillTimeInMinutes");
        if (refillTime != null) {
            refillTimeInMinutes = Integer.parseInt(refillTime);
        }
    }
    
    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) 
            throws IOException, ServletException {
        
        
        
        
        HttpServletRequest httpRequest = (HttpServletRequest) request;
        HttpServletResponse httpResponse = (HttpServletResponse) response;
        
        // Get client identifier (using IP address - consider using API key or user ID in production)
        String clientId = httpRequest.getRemoteAddr();
        
        // Get the bucket for this client, creating a new one if needed
        Bucket bucket = clientBuckets.computeIfAbsent(clientId, this::createNewBucket);
        
//        System.out.println("Rate limit filter triggered for client: " + clientId);
//        System.out.println("Current bucket status: " + bucket.getAvailableTokens());
//        
//        logger.info("Rate limit filter triggered for client: ", clientId);
//        logger.info("Current bucket status: ",bucket.getAvailableTokens());

          logger.info("Rate limit filter triggered for client: {}", clientId);
          logger.info("Current bucket status: {}", bucket.getAvailableTokens());
        
        
        
        // Try to consume a token from the bucket
        if (bucket.tryConsume(1)) {
            // Request allowed, proceed with the filter chain
            chain.doFilter(request, response);
        } else {
            // Rate limit exceeded
            httpResponse.setStatus(429); // HTTP 429 - Too Many Requests
            httpResponse.setContentType("application/json");
            httpResponse.getWriter().write("{\"status\":\"error\",\"message\":\"Rate limit exceeded. Please try again later.\"}");
        }
    }
    
   private Bucket createNewBucket(String clientId) {
    // Use intervally instead of greedy refill
    Refill refill = Refill.intervally(refillTokens, Duration.ofMinutes(refillTimeInMinutes));
    
    // Create bandwidth with initial capacity and refill strategy
    Bandwidth limit = Bandwidth.classic(bucketCapacity, refill);
    
    logger.info("Created new rate limit bucket for client: {} with capacity: {}, refill: {} tokens per {} minutes", 
                clientId, bucketCapacity, refillTokens, refillTimeInMinutes);
    
    return Bucket4j.builder().addLimit(limit).build();
}
    @Override
    public void destroy() {
        // Cleanup
        clientBuckets.clear();
    }
}