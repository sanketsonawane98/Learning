/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.test.service;

import java.net.InetSocketAddress;
import java.net.Proxy;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.client.SimpleClientHttpRequestFactory;
import org.springframework.stereotype.Service;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

/**
 *
 * @author Sanket.Sonawane
 */
@Service
public class commonServiceImpl implements commonService{
    
    
    @Value("${app.apiUrl}")
    private String apiUrl;
    
    @Value("${app.tokenUrl}")
    private String tokenUrl;
    
    @Value("${app.username}")
    private String username;
    
    @Value("${app.password}")
    private String password;
    
    @Value("${app.grant.type}")
    private String grant_type;
    
    @Value("${app.proxy.host}")
    private String proxy_host;
    
    @Value("${app.proxy.port}")
    private int proxy_port;
    
    @Override
    public ResponseEntity<String> makePostRequest(String url, Object formData, String type, String authToken) {
        try {
            
            
            SimpleClientHttpRequestFactory requestFactory = new SimpleClientHttpRequestFactory();
            Proxy proxy = new Proxy(Proxy.Type.HTTP, new InetSocketAddress(proxy_host, proxy_port));
            requestFactory.setProxy(proxy);
            RestTemplate restTemplate = new RestTemplate(requestFactory);
            

             HttpHeaders headers = new HttpHeaders();
             
             HttpEntity<?> requestEntity;
             
             if("token".equals(type))
             {
                headers.add("Content-Type", "application/x-www-form-urlencoded");
                requestEntity = new HttpEntity<>((MultiValueMap<String, String>) formData, headers);
             }
             else
             {
                 headers.add("Content-Type", "application/json");
                 if (authToken != null && !authToken.isEmpty())
                 {
                     headers.add("Authorization", "Bearer " + authToken);
                 }
                 
                 requestEntity = new HttpEntity<>(formData, headers);
                  
             }
            
                        
            ResponseEntity<String> response = restTemplate.postForEntity(url, requestEntity, String.class);
            
            
            return response;
            
        } catch (RestClientException e) {
            System.err.println("Error making request: " + e.getMessage());
            e.printStackTrace();
            //return "Error: " + e.getMessage();
            return null;
        }
    }
    
    @Override
    public String getAccessToken()
    {
        
        MultiValueMap<String, String> formData = new LinkedMultiValueMap<>();
            formData.add("username", username);
            formData.add("password", password);
            formData.add("grant_type", grant_type);
            
        ResponseEntity<String> res = makePostRequest(tokenUrl, formData, "token", null);
        
        if(res==null)return null;
        
        String tokenRes = res.getBody();
        
        int count=0; String key = "";
                
                for(int i=0;i<tokenRes.length();i++)
                {
                    if(tokenRes.charAt(i)=='"')
                    {
                        count++;
                        if(count==3)
                        {
                            i++;
                            while(i<tokenRes.length() && tokenRes.charAt(i)!='"')
                            {
                                key+=tokenRes.charAt(i);
                                i++;
                            }
                            break;
                        }
                    }
                    
                }
        return key;
    }
    

      @Override
      public <T>ResponseEntity<String> getDetails(T requestBean)
      {
        String accessToken = getAccessToken();
//        
        if(accessToken==null)
        {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("something wrong");
        }

        
        ResponseEntity<String> commonRes = makePostRequest(
            apiUrl,
            requestBean,
            "other",
            accessToken
        );
        
        return commonRes;
      }
      
}
