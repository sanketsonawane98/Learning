/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.test.service;

import com.test.bean.UserRequestBean;
import com.test.entity.User;
import com.test.repository.UserRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

/**
 *
 * @author Sanket.Sonawane
 */
@Service
public class userServiceImpl implements userService{
    
//    @Autowired
//    UserRepository userRepository;
    
    private static final Logger logger = LoggerFactory.getLogger(userServiceImpl.class);    

    
    @Override
    public ResponseEntity<?> createUser(UserRequestBean u){
        
        User user = new User();
        user.setUsername(u.getUsername());
        user.setPassword(u.getPassword());
        user.setRole(u.getRole());
        
        logger.info("in createUser");
        
        logger.info("user entity : {}",user);
        
//        userRepository.save(user);
        
        logger.info("user saved");
        
        logger.info("in userServiceImpl : createUser");
        return ResponseEntity.status(200).body("user created");   
    }

}
