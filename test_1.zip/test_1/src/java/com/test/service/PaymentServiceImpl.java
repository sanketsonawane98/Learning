/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.test.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.test.bean.PaymentErrorResponseBean;
import com.test.bean.PaymentRequestBean;
import com.test.bean.PaymentResponseBean;
import java.net.InetSocketAddress;
import java.net.Proxy;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.http.client.SimpleClientHttpRequestFactory;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;

/**
 *
 * @author Sanket.Sonawane
 */
@Service
public class PaymentServiceImpl implements PaymentService{
    
    
    private static final Logger logger = LoggerFactory.getLogger(PaymentServiceImpl.class);    
    @Value("${app.proxy.host}")
    private String proxy_host;
    
    @Value("${app.proxy.port}")
    private int proxy_port;
    
    @Value("${app.payment.auth.username}")
    private String auth_username;
    
    @Value("${app.payment.auth.token}")
    private String auth_token;
 
    @Value("${app.payment.url}")
    private String apiUrl;
    
    @Override
    public ResponseEntity<?> getData(PaymentRequestBean p)
    {
            
        
        try {
            
            logger.info("in PaymentServiceImpl :  method getData" );
            SimpleClientHttpRequestFactory requestFactory = new SimpleClientHttpRequestFactory();
            Proxy proxy = new Proxy(Proxy.Type.HTTP, new InetSocketAddress(proxy_host, proxy_port));
            requestFactory.setProxy(proxy);
            RestTemplate restTemplate = new RestTemplate(requestFactory);
            
            logger.info("rest template created");
            
            HttpHeaders headers = new HttpHeaders();
             
             HttpEntity<?> requestEntity;
             
             headers.add("Content-Type", "application/json");
             headers.add("authentication-username",auth_username);
             headers.add("authentication-token",auth_token);
             
             logger.info("headers : {}", headers);
             
             requestEntity = new HttpEntity<>(p, headers);
             
             logger.debug("request : {}", requestEntity);
             
             ResponseEntity<String> response = restTemplate.postForEntity(apiUrl, requestEntity, String.class);
             
             logger.info("response : {}", response);
             
                 // Get the raw JSON response
             String responseBody = response.getBody();
             ObjectMapper mapper = new ObjectMapper();
             
                 // First try to determine what type of response it is
             JsonNode rootNode = mapper.readTree(responseBody);
             
             logger.info("rootNode : {}",rootNode);
             
             
             if(rootNode.has("statusCode") && rootNode.get("statusCode").asText().equals("FA_200"))
             {
                 
                 PaymentResponseBean successResponse = mapper.convertValue(rootNode, PaymentResponseBean.class);
                 
                 logger.info("successResponse : {}",successResponse);
                 
                 return ResponseEntity.status(response.getStatusCode()).body(successResponse);
             }
             
             else
             {
                 PaymentErrorResponseBean errorResponse = mapper.convertValue(rootNode, PaymentErrorResponseBean.class);
                 
                 logger.info("errorResponse : {}",errorResponse);
                 
                 return ResponseEntity.status(response.getStatusCode()).body(errorResponse);
             }
             
            
        } catch (Exception e) {
            
            logger.error("Error calling external API: {} - {}", e.getClass().getName(), e.getMessage());
            logger.error("Exception details:", e);
            
            PaymentErrorResponseBean pe = new PaymentErrorResponseBean();
            pe.setErrorMessage("something went wrong");
            
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
            .body(pe);
            
        }
    }
}
